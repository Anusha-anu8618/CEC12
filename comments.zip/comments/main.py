# Simple Sentiment Analysis using Text Processing

# Define positive and negative words
positive_words = {"good", "great", "excellent", "amazing", "love", "nice", "happy", "best"}
negative_words = {"bad", "worst", "poor", "hate", "terrible", "awful", "sad"}

# Counters
positive_count = 0
negative_count = 0
neutral_count = 0

# Read comments from file
with open("comments.txt", "r") as file:
    comments = file.readlines()

# Process each comment
for comment in comments:
    comment = comment.lower()  # Convert to lowercase
    words = comment.split()    # Split into words

    pos = 0
    neg = 0

    for word in words:
        if word in positive_words:
            pos += 1
        elif word in negative_words:
            neg += 1

    # Classify comment
    if pos > neg:
        positive_count += 1
    elif neg > pos:
        negative_count += 1
    else:
        neutral_count += 1

# Total comments
total = len(comments)

# Calculate percentages
positive_percent = (positive_count / total) * 100
negative_percent = (negative_count / total) * 100
neutral_percent = (neutral_count / total) * 100

# Output results
print("Total Comments:", total)
print(f"Positive Comments: {positive_count} ({positive_percent:.2f}%)")
print(f"Negative Comments: {negative_count} ({negative_percent:.2f}%)")
print(f"Neutral Comments: {neutral_count} ({neutral_percent:.2f}%)")