from flask import Flask, render_template, request, jsonify
from google import genai

app = Flask(__name__)

# 🔑 API key
client = genai.Client(api_key="AQ.Ab8RN6L5lcD1vQD74JwWVY2hb6FT7WTDC2Lmfi_aZw6LzDYviA")

# ✅ Define model name clearly (better practice)
MODEL_NAME = "gemini-1.5-flash"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get', methods=['POST'])
def chatbot():
    user_input = request.form.get('message', '')

    if not user_input:
        return jsonify({"response": "Please type something!"})

    try:
        response = client.models.generate_content(
            model=MODEL_NAME,   # 👈 model used here
            contents=user_input
        )
        reply = response.text

    except Exception as e:
        reply = "Error: " + str(e)

    return jsonify({"response": reply})

if __name__ == '__main__':
    app.run(debug=True)