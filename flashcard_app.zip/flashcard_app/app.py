from flask import Flask, render_template, request, redirect, url_for, session, flash
import json, os, random
from functools import wraps

app = Flask(__name__)
app.secret_key = "flashcard_secret"

DATA_FILE = "cards.json"
USER_FILE = "users.json"


# ---------------- JSON HELPERS ----------------
def load_json(file):
    if not os.path.exists(file):
        return {}
    with open(file, "r") as f:
        return json.load(f)

def save_json(file, data):
    with open(file, "w") as f:
        json.dump(data, f, indent=4)


# ---------------- LOGIN REQUIRED DECORATOR ----------------
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


# ---------------- HOME REDIRECT ----------------
@app.route("/")
def home():
    if "user" not in session:
        return redirect(url_for("login"))
    return redirect(url_for("index"))


# ---------------- SIGNUP ----------------
@app.route("/signup", methods=["GET", "POST"])
def signup():
    users = load_json(USER_FILE)

    if request.method == "POST":
        username = request.form["username"]

        if username in users:
            flash("⚠️ User already exists!")
            return redirect(url_for("signup"))

        users[username] = {
            "password": request.form["password"],
            "email": request.form["email"],
            "phone": request.form["phone"]
        }

        save_json(USER_FILE, users)

        flash("🎉 Account created successfully!")
        return redirect(url_for("login"))

    return render_template("signup.html")


# ---------------- LOGIN ----------------
@app.route("/login", methods=["GET", "POST"])
def login():
    users = load_json(USER_FILE)

    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username in users and users[username]["password"] == password:
            session["user"] = username
            flash("✅ Login successful!")
            return redirect(url_for("dashboard"))
        else:
            flash("❌ Invalid username or password!")

    return render_template("login.html")


# ---------------- LOGOUT ----------------
@app.route("/logout")
def logout():
    session.clear()
    flash("👋 Logged out successfully!")
    return redirect(url_for("login"))


# ---------------- DASHBOARD ----------------
@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", user=session["user"])


# ---------------- PROFILE ----------------
@app.route("/profile")
@login_required
def profile():
    users = load_json(USER_FILE)
    user = session["user"]

    return render_template(
        "profile.html",
        username=user,
        user=users.get(user, {})
    )


# ---------------- DECK LIST ----------------
@app.route("/decks")
@login_required
def index():
    data = load_json(DATA_FILE)
    return render_template("index.html", decks=data, user=session["user"])


# ---------------- CREATE FLASHCARD ----------------
@app.route("/create", methods=["GET", "POST"])
@login_required
def create():
    data = load_json(DATA_FILE)

    if request.method == "POST":
        deck = request.form["deck"]

        if deck not in data:
            data[deck] = []

        data[deck].append({
            "question": request.form["question"],
            "answer": request.form["answer"]
        })

        save_json(DATA_FILE, data)
        flash("💾 Flashcard saved!")
        return redirect(url_for("index"))

    return render_template("create.html", user=session["user"])


# ---------------- STUDY MODE ----------------
@app.route("/study/<deck>")
@login_required
def study(deck):
    data = load_json(DATA_FILE)

    if deck not in data or len(data[deck]) == 0:
        flash("⚠️ No flashcards in this deck!")
        return redirect(url_for("index"))

    session["deck"] = deck
    session["cards"] = data[deck]
    session["index"] = 0

    return render_template("study.html", card=data[deck][0], deck=deck)


# ---------------- NEXT CARD ----------------
@app.route("/next/<action>")
@login_required
def next_card(action):
    cards = session.get("cards", [])
    index = session.get("index", 0)

    if action == "shuffle":
        random.shuffle(cards)

    index += 1

    if index >= len(cards):
        flash("🎉 You completed this deck!")
        return redirect(url_for("dashboard"))

    session["cards"] = cards
    session["index"] = index

    return render_template("study.html", card=cards[index], deck=session.get("deck"))


# ---------------- RUN APP ----------------
if __name__ == "__main__":
    app.run(debug=True)