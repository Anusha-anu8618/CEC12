from flask import Flask, render_template, request, redirect, session, url_for, flash

app = Flask(__name__)
app.secret_key = "secret123"

# ==================================================
# DATABASE
# ==================================================
users = {
    "admin": {
        "email": "admin@gmail.com",
        "phone": "9999999999",
        "password": "admin123",
        "role": "admin",
        "created_by": "system"
    }
}

# ==================================================
# HOME
# ==================================================
@app.route('/')
def home():
    return redirect(url_for('login'))

# ==================================================
# LOGIN
# ==================================================
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        if username in users and users[username]['password'] == password:
            session['user'] = username
            session['role'] = users[username]['role']

            flash("✅ Login Successful!", "success")
            return redirect(url_for('dashboard'))
        else:
            error = "❌ Invalid Username or Password"

    return render_template("login.html", error=error)

# ==================================================
# SIGNUP
# ==================================================
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    errors = {}

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        password = request.form.get('password', '').strip()

        if not username:
            errors['username'] = "Username required"
        elif username in users:
            errors['username'] = "Username already exists"

        if not email:
            errors['email'] = "Email required"

        if not phone:
            errors['phone'] = "Phone required"

        if not password:
            errors['password'] = "Password required"

        if not errors:
            users[username] = {
                "email": email,
                "phone": phone,
                "password": password,
                "role": "user",
                "created_by": "self"
            }

            flash("✅ Signup Successful!", "success")
            return redirect(url_for('login'))

    return render_template("signup.html", errors=errors)

# ==================================================
# DASHBOARD
# ==================================================
@app.route('/dashboard')
def dashboard():

    if 'user' not in session:
        return redirect(url_for('login'))

    if session['role'] == "admin":

        query = request.args.get('query', '').strip().lower()
        page = request.args.get('page', 1, type=int)
        per_page = 5

        data_list = list(users.items())

        filtered = []
        not_found = False   # ✅ IMPORTANT FLAG

        # ================= SEARCH LOGIC =================
        if query:
            for username, data in data_list:
                if (
                    query in username.lower()
                    or query in data['email'].lower()
                    or query in data['phone']
                ):
                    filtered.append((username, data))

            # ❌ NOTHING FOUND
            if len(filtered) == 0:
                not_found = True

        else:
            filtered = data_list

        total = len(filtered)
        total_pages = (total + per_page - 1) // per_page

        if total_pages == 0:
            total_pages = 1

        start = (page - 1) * per_page
        end = start + per_page

        paginated = filtered[start:end]

        return render_template(
            "dashboard.html",
            user=session['user'],
            role="admin",
            users=paginated,
            page=page,
            total_pages=total_pages,
            query=query,
            user_count=len(users),
            not_found=not_found   # ✅ SEND TO HTML
        )

    else:
        return render_template(
            "dashboard.html",
            user=session['user'],
            role="user",
            users=[],
            page=1,
            total_pages=1,
            query="",
            user_count=0,
            not_found=False
        )

# ==================================================
# USERS LIST
# ==================================================
@app.route('/users_list')
def users_list():

    if 'user' not in session:
        return redirect(url_for('login'))

    if session['role'] != "admin":
        flash("❌ Only Admin Can Access Users List", "error")
        return redirect(url_for('dashboard'))

    return render_template(
        "users_list.html",
        user=session['user'],
        users=users.items(),
        total_users=len(users)
    )

# ==================================================
# ADD USER
# ==================================================
@app.route('/add_user', methods=['POST'])
def add_user():

    if 'user' not in session:
        return redirect(url_for('login'))

    if session['role'] != "admin":
        return redirect(url_for('dashboard'))

    username = request.form.get('username', '').strip()
    email = request.form.get('email', '').strip()
    phone = request.form.get('phone', '').strip()
    password = request.form.get('password', '').strip()

    if username in users:
        flash("❌ Username already exists", "error")
    else:
        users[username] = {
            "email": email,
            "phone": phone,
            "password": password,
            "role": "user",
            "created_by": "admin"
        }

        flash("✅ User Added Successfully", "success")

    return redirect(url_for('dashboard'))

# ==================================================
# UPDATE USER
# ==================================================
@app.route('/update_inline/<username>', methods=['POST'])
def update_inline(username):

    if username in users:
        users[username]['email'] = request.form.get('email', '')
        users[username]['phone'] = request.form.get('phone', '')
        users[username]['password'] = request.form.get('password', '')

        flash("✅ Updated Successfully", "success")

    return redirect(url_for('dashboard'))

# ==================================================
# DELETE USER
# ==================================================
@app.route('/delete/<username>')
def delete_user(username):

    if username != "admin" and username in users:
        users.pop(username)
        flash("🗑 User Deleted", "success")

    return redirect(url_for('dashboard'))

# ==================================================
# PROFILE
# ==================================================
@app.route('/profile')
def profile():

    username = session['user']

    return render_template(
        "profile.html",
        user=username,
        email=users[username]['email'],
        phone=users[username]['phone']
    )

# ==================================================
# LOGOUT
# ==================================================
@app.route('/logout')
def logout():
    session.clear()
    flash("✅ Logged Out Successfully", "success")
    return redirect(url_for('login'))

# ==================================================
# RUN APP
# ==================================================
if __name__ == '__main__':
    app.run(debug=True)